#include "tree.h"
#include <iostream>

using namespace std;

adrNode newNode_1301213093(infotype x){
    adrNode p = new node;
    info(p) = x;
    left(p) = nil;
    right(p) = nil;
    return p;
}

adrNode findNode_1301213093(adrNode root, infotype x){
    if (root == nil){
        return nil;
    }if (info(root) == x){
        return root;
    }

    adrNode p = findNode_1301213093(left(root), x);
    if (p != nil){
        return p;
    }
    return findNode_1301213093(right(root),x);
}

void insertNode_1301213093(adrNode &root, adrNode p){
    if (root == nil){
        root = p;
    }else{
        if (info(p) < info(root)){
            insertNode_1301213093(left(root),p);
        }else{
            insertNode_1301213093(right(root),p);
        }
    }
}

void printPreOrder_1301213093(adrNode root){
    if (root == nil){
        return;
    }
    cout << info(root) << " ";
    printPreOrder_1301213093(left(root));
    printPreOrder_1301213093(right(root));
}

void printDescendant_1301213093(adrNode root, infotype x){
    adrNode p = findNode_1301213093(root, x);
    if (p == nil){
        cout << "Tidak ada node" << endl;
    }
    printPreOrder_1301213093(left(p));
    printPreOrder_1301213093(right(p));
}

int sumNode_1301213093(adrNode root){
    if (root == nil){
        return 0;
    }
    return info(root) + sumNode_1301213093(left(root)) + sumNode_1301213093(right(root));
}
int countLeaves_1301213093(adrNode root){
    if (root == nil){
        return 0;
    }
    if (left(root) == nil && right(root) == nil){
        return 1;
    }
    return countLeaves_1301213093(left(root)) + countLeaves_1301213093(right(root));
}

int heightTree_1301213093(adrNode root){
    if (root == nil){
        return 0;
    }
    int lheight = heightTree_1301213093(left(root));
    int rheight = heightTree_1301213093(right(root));
    return max(lheight, rheight) + 1;
}
